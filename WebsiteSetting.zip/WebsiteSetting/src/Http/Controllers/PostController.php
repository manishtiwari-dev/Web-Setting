<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use ApiHelper;
use App\Http\Controllers\Controller;
use App\Models\Language;
use App\Models\UserBusiness;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Modules\Ecommerce\Models\SeoMeta;
use Modules\WebsiteSetting\Models\PostDescriptions;
use Modules\WebsiteSetting\Models\Posts;
use Modules\WebsiteSetting\Models\Super\LandingPost;
use Modules\WebsiteSetting\Models\Super\LandingPostDescription;
use Modules\WebsiteSetting\Models\Super\LandingSeoMeta;
use Modules\WebsiteSetting\Models\Super\SuperPostCategory;
use Modules\WebsiteSetting\Models\Super\SuperPostTag;
use Modules\WebsiteSetting\Models\Super\SuperPostAuthor;
use Modules\WebsiteSetting\Models\PostCategory;
use Modules\WebsiteSetting\Models\PostToTag;
use Modules\WebsiteSetting\Models\PostTag;
use Modules\WebsiteSetting\Models\PostAuthor;



class PostController extends Controller
{
    public $page = 'blog_setting';
    public $landingpage = 'super_blog_setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int) $request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        $language = $request->language;

        if ($userType == 'subscriber') {
            $data_query = Posts::with('descriptionDetails');
        } else {

            $data_query = LandingPost::with('descriptionDetails');
        }

        if (!empty($search)) {
            $data_query = $data_query->where("slug", "LIKE", "%{$search}%")
                ->orWhereHas('descriptionDetails', function ($data_query) use ($search) {
                    $data_query->where("post_title", "LIKE", "%{$search}%");
                });
        }

        // if (!empty($search))
        //     $data_query = $data_query->where("post_title","LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('created_at', 'DESC');
        }

        $skip = ($current_page == 1) ? 0 : (int) ($current_page - 1) * $perPage;

        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $data_list = $data_list->map(function ($data) use ($language) {

            $cate = $data->descriptionDetails()->where('languages_id', ApiHelper::getLangid($language))->first();

            $data->post_title = ($cate == null) ? '' : $cate->post_title;
            $data->post_content = ($cate == null) ? '' : $cate->post_content;
            //   $data->status = ($data->status == 1) ? "active" : "deactive";
            $data->banner_image = ApiHelper::getFullImageUrl($data->banner_image);
            $data->thumb_img = ApiHelper::getFullImageUrl($data->thumbnail_image, 'index-list1');

            return $data;
        });

        // $data->feature_icon = ApiHelper::getFullImageUrl($data->feature_icon);

        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int) $user_count / (int) $perPage),
            'per_page' => $perPage,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function language_list($api_token)
    {
        $api_token = $api_token;

        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {

            $language = ApiHelper::allSupportLang();
        } else {

            $language = ApiHelper::allSuperSupportLang();
        }

        return $language;
    }



    public function create(Request $request)
    {

        $api_token = $request->api_token;
        $language = (new self)->language_list($api_token);


        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $postCategory = PostCategory::select('category_name as label', 'category_id as value')->get();
            $postTag = PostTag::select('tags_name as label', 'tags_id as value')->get();
            //    $postAuthor = PostAuthor::all();
            $postAuthor = PostAuthor::select('author_name as label', 'author_id as value')->get();
        } else {


            $postCategory = SuperPostCategory::select('category_name as label', 'category_id as value')->get();
            $postTag = SuperPostTag::select('tags_name as label', 'tags_id as value')->get();

            $postAuthor = SuperPostAuthor::select('author_name as label', 'author_id as value')->get();
        }




        $res = [
            'language' => $language,
            'postCategory' => $postCategory,
            'postTag' => $postTag,
            'postAuthor' => $postAuthor,
        ];


        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function store(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        if ($userType == 'subscriber') {

            //validation check

            foreach (ApiHelper::allSupportLang() as $key => $value) {

                //validation check
                $validator = Validator::make(
                    $request->all(),
                    [
                        'post_title_' . $value->languages_id => 'required',
                        'post_content_' . $value->languages_id => 'required',
                        'post_excerpt_' . $value->languages_id => 'required',
                    ],
                    [

                        'post_title_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'POST_TITLE_REQUIRED',
                        'post_content_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'POST_CONTENT_REQUIRED',
                        'post_excerpt_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'POST_EXCERPT_REQUIRED',

                    ]

                );
                if ($validator->fails()) {
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
                }
            }
            //store pages

            $saveData = $request->only(['banner_image', 'created_at', 'thumbnail_image', 'author_id']);
            //  $saveData['slug'] = "";

            $postSlug = Posts::where('slug',  $request->slug)->first();
            if (empty($postSlug)) {
                $saveData['slug'] = $request->slug;
            } else {
                return ApiHelper::JSON_RESPONSE(false, [], 'POSTS_SLUG_ALREADY_EXISTS');
                // $saveData['pages_slug'] = "";
            }

            $saveData['created_by'] = ApiHelper::get_user_id_from_token($api_token);
            // uplad image to live. current in temp
            if ($saveData['banner_image'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['banner_image'], 1, 'post', '', false);
            }


            if ($saveData['thumbnail_image'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['thumbnail_image'], 1, 'post/thumb', '', false);
            }

            //   ApiHelper::image_upload_with_crop($api_token,$saveData['img'], 4, 'post');

            $cat = Posts::create($saveData);
            $cat_ary = explode(',', $request->category_id);
            $tag_ary = explode(',', $request->tags_id);
            // attach category to post
            if (!empty($cat_ary)) {
                // for post to category
                $postToCategory = [];
                foreach ($cat_ary as $key => $catid) {
                    $postToCategory[$key]['category_id'] = $catid;
                    $postToCategory[$key]['post_id'] = $cat->post_id;
                }
                $cat->post_to_categories()->attach($postToCategory);
            }



            // attach category to post
            if (!empty($tag_ary)) {
                // for post to category
                $postToTag = [];
                foreach ($tag_ary as $key => $catid) {
                    $postToTag[$key]['tags_id'] = $catid;
                    $postToTag[$key]['post_id'] = $cat->post_id;
                }
                $cat->postToTag()->attach($postToTag);
            }


            // store post details
            foreach (ApiHelper::allSupportLang() as $key => $value) {

                $post_title = "post_title_" . $value->languages_id;
                $post_content = "post_content_" . $value->languages_id;
                $post_excerpt = "post_excerpt_" . $value->languages_id;

                $seometa_title = "seometa_title_" . $value->languages_id;
                $seometa_desc = "seometa_desc_" . $value->languages_id;

                // if ($value->languages_code == 'en') {

                //     $post_data = Posts::find($cat->post_id);
                //     if (empty($request->slug)) {
                //         $post_data->slug = Str::slug($request->$post_title);
                //     } else {

                //         $post_data->slug = $request->slug;
                //     }

                //     $post_data->save();
                // }

                $Postdesc = PostDescriptions::create([
                    'post_id' => $cat->post_id,
                    'post_title' => $request->$post_title,
                    'post_content' => $request->$post_content,
                    'post_excerpt' => $request->$post_excerpt,
                    'languages_id' => $value->languages_id,
                ]);

                if (!empty($request->$post_title) || !empty($request->$post_content)) {
                    SeoMeta::create([
                        'page_type' => 4,
                        'reference_id' => $Postdesc->post_description,
                        'language_id' => $value->languages_id,
                        'seometa_title' => $request->$seometa_title,
                        'seometa_desc' => $request->$seometa_desc,
                    ]);
                }
            }
        } else {

            foreach (ApiHelper::allSuperSupportLang() as $key => $value) {

                //validation check
                $validator = Validator::make(
                    $request->all(),
                    [
                        'post_title_' . $value->languages_id => 'required',
                        'post_content_' . $value->languages_id => 'required',
                        'post_excerpt_' . $value->languages_id => 'required',
                    ],
                    [

                        'post_title_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'POST_TITLE_REQUIRED',
                        'post_content_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'POST_CONTENT_REQUIRED',
                        'post_excerpt_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'POST_EXCERPT_REQUIRED',

                    ]

                );
                if ($validator->fails()) {
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
                }
            }

            $saveData = $request->only(['banner_image', 'created_at', 'thumbnail_image', 'author_id']);
            $postSlug = LandingPost::where('slug',  $request->slug)->first();
            if (empty($postSlug)) {
                $saveData['slug'] = $request->slug;
            } else {
                return ApiHelper::JSON_RESPONSE(false, [], 'POSTS_SLUG_ALREADY_EXISTS');
                // $saveData['pages_slug'] = "";
            }

            $saveData['created_by'] = ApiHelper::get_user_id_from_token($api_token);

            // uplad image to live. current in temp
            if ($saveData['banner_image'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['banner_image'], 1, 'post', '', false);
            }

            if ($saveData['thumbnail_image'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['thumbnail_image'], 1, 'post/thumb', '', false);
            }
            //   ApiHelper::image_upload_with_crop($api_token,$saveData['img'], 4, 'post');

            $cat = LandingPost::create($saveData);

            $cat_ary = explode(',', $request->category_id);
            $tag_ary = explode(',', $request->tags_id);
            // attach category to post
            if (!empty($cat_ary)) {
                // for post to category
                $postToCategory = [];
                foreach ($cat_ary as $key => $catid) {
                    $postToCategory[$key]['category_id'] = $catid;
                    $postToCategory[$key]['post_id'] = $cat->post_id;
                }
                $cat->post_to_categories()->attach($postToCategory);
            }



            // attach category to post
            if (!empty($tag_ary)) {
                // for post to category
                $postToTag = [];
                foreach ($tag_ary as $key => $catid) {
                    $postToTag[$key]['tags_id'] = $catid;
                    $postToTag[$key]['post_id'] = $cat->post_id;
                }
                $cat->postToTag()->attach($postToTag);
            }



            // store post details
            foreach (ApiHelper::allSuperSupportLang() as $key => $value) {

                $post_title = "post_title_" . $value->languages_id;
                $post_content = "post_content_" . $value->languages_id;
                $post_excerpt = "post_excerpt_" . $value->languages_id;
                $seometa_title = "seometa_title_" . $value->languages_id;
                $seometa_desc = "seometa_desc_" . $value->languages_id;

                // if ($value->languages_code == 'en') {

                //     $post_data = LandingPost::find($cat->post_id);
                //     if (empty($request->slug)) {
                //         $post_data->slug = Str::slug($request->$post_title);
                //     } else {

                //         $post_data->slug = $request->slug;
                //     }

                //     $post_data->save();
                // }

                $Postdesc = LandingPostDescription::create([
                    'post_id' => $cat->post_id,
                    'post_title' => $request->$post_title,
                    'post_content' => $request->$post_content,
                    'post_excerpt' => $request->$post_excerpt,
                    'languages_id' => $value->languages_id,
                ]);

                if (!empty($request->$post_title) || !empty($request->$post_content)) {
                    LandingSeoMeta::create([
                        'page_type' => 4,
                        'reference_id' => $Postdesc->post_description,
                        'language_id' => $value->languages_id,
                        'seometa_title' => $request->$seometa_title,
                        'seometa_desc' => $request->$seometa_desc,
                    ]);
                }
            }
        }

        if ($cat) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_POST_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_POST_ADD');
        }
    }

    public function edit(Request $request)
    {

        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        if ($userType == 'subscriber') {
            $postCategory = PostCategory::select('category_name as label', 'category_id as value')->get();
            $postTag = PostTag::select('tags_name as label', 'tags_id as value')->get();
            //.  $postAuthor = PostAuthor::all();
            $postAuthor = PostAuthor::select('author_name as label', 'author_id as value')->get();



            $data_list = Posts::with('descriptionDetails', 'descriptionDetails.seo')->find($request->post_id);
            if (!empty($data_list->author_id)) {
                $data_list->selectedAuthor = PostAuthor::select('author_name as label', 'author_id as value')->whereRaw('author_id IN(' . $data_list->author_id . ') ')->get();
            }

            if (!empty($data_list)) {
                $post_to_categories = $data_list->post_to_categories;
                $post_tag = $data_list->postToTag;
                //   return ApiHelper::JSON_RESPONSE(true, $post_tag, '');
                $selected_category = [];
                if (!empty($post_to_categories)) {
                    foreach ($post_to_categories as $key => $cat) {
                        $label = ($cat !== null) ? $cat->category_name : '';
                        array_push($selected_category, [
                            "label" => $label,
                            "value" => $cat->category_id,
                        ]);
                    }
                }
                $data_list->selected_category = $selected_category;
                $data_list->selected_tag = $post_tag;


                $data_list->banner_image_url = ApiHelper::getFullImageUrl($data_list->banner_image, 'index-list');
                $data_list->thumbnail_image_url = ApiHelper::getFullImageUrl($data_list->thumbnail_image, 'index-list');
            }
        } else {

            $postCategory = SuperPostCategory::select('category_name as label', 'category_id as value')->get();
            $postTag = SuperPostTag::select('tags_name as label', 'tags_id as value')->get();
            //    $postAuthor = SuperPostAuthor::all();
            $postAuthor = SuperPostAuthor::select('author_name as label', 'author_id as value')->get();


            $data_list = LandingPost::with('descriptionDetails', 'descriptionDetails.seo')->find($request->post_id);
            if (!empty($data_list->author_id)) {
                $data_list->selectedAuthor = SuperPostAuthor::select('author_name as label', 'author_id as value')->whereRaw('author_id IN(' . $data_list->author_id . ') ')->get();
            }

            if (!empty($data_list)) {
                $post_to_categories = $data_list->post_to_categories;
                $post_tag = $data_list->postToTag;
                //   return ApiHelper::JSON_RESPONSE(true, $post_tag, '');
                $selected_category = [];
                if (!empty($post_to_categories)) {
                    foreach ($post_to_categories as $key => $cat) {
                        $label = ($cat !== null) ? $cat->category_name : '';
                        array_push($selected_category, [
                            "label" => $label,
                            "value" => $cat->category_id,
                        ]);
                    }
                }
                $data_list->selected_category = $selected_category;
                $data_list->selected_tag = $post_tag;


                $data_list->banner_image_url = ApiHelper::getFullImageUrl($data_list->banner_image, 'index-list');
                $data_list->thumbnail_image_url = ApiHelper::getFullImageUrl($data_list->thumbnail_image, 'index-list');
            }
        }

        $language = (new self)->language_list($api_token);

        // $allTaglist = PostTag::all();

        $res = [
            'data_list' => $data_list,
            'language' => $language,
            'postCategory' => $postCategory,
            'postTag' => $postTag,
            'postAuthor' => $postAuthor,

        ];


        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $post_id = $request->post_id;
        if ($userType == 'subscriber') {
            //validation
            foreach (ApiHelper::allSupportLang() as $key => $value) {

                //validation check
                $validator = Validator::make(
                    $request->all(),
                    [
                        'post_title_' . $value->languages_id => 'required',
                        'post_content_' . $value->languages_id => 'required',
                        'post_excerpt_' . $value->languages_id => 'required',
                    ],
                    [

                        'post_title_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'POST_TITLE_REQUIRED',
                        'post_content_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'POST_CONTENT_REQUIRED',
                        'post_excerpt_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'POST_EXCERPT_REQUIRED',

                    ]

                );
                if ($validator->fails()) {
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
                }
            }

            // store posts
            $saveData = $request->only(['status', 'created_at', 'author_id', 'banner_image', 'thumbnail_image']);
            $saveData['slug'] = "";

            // if ($saveData['banner_image'] != '') 
            if ($request->has("banner_image") && !empty($request->banner_image)) {
                ApiHelper::image_upload_with_crop($api_token, $saveData['banner_image'], 1, 'post', '', false);
            }



            if ($request->has("thumbnail_image") && !empty($request->banner_image))
            // if ($saveData['thumbnail_image'] != '') 
            {
                ApiHelper::image_upload_with_crop($api_token, $saveData['thumbnail_image'], 1, 'post/thumb', '', false);
            }

            $cat = Posts::where('post_id', $post_id)->update($saveData);

            // if ($request->has("banner_image") && !empty($request->banner_image)) {
            //     ApiHelper::image_upload_with_crop($api_token, $request->banner_image, 1, $post_id, '', false);

            //     Posts::where('post_id', $post_id)->update(['banner_image' => $request->banner_image]);
            // }

            // if ($request->has("thumbnail_image") && !empty($request->thumbnail_image)) {
            //     ApiHelper::image_upload_with_crop($api_token, $request->thumbnail_image, 1, $post_id, '', false);

            //     Posts::where('post_id', $post_id)->update(['thumbnail_image' => $request->thumbnail_image]);
            // }


            // deattach category
            $postCat = Posts::find($post_id);
            $postCat->post_to_categories()->detach();

            // attach category to post
            if (!empty($request->category_id)) {
                // for post to category
                $postToCategory = [];
                foreach ($request->category_id as $key => $catid) {
                    $postToCategory[$key]['category_id'] = $catid;
                    $postToCategory[$key]['post_id'] = $postCat->post_id;
                }
                $postCat->post_to_categories()->attach($postToCategory);
            }



            $tag_ary = explode(',', $request->tags_id);
            //     $tag_ary =  $request->tags_id;
            //$postCat->postToTag()->detach();

            // attach category to post
            if (!empty($tag_ary)) {
                // for post to category
                $postToTag = [];
                foreach ($tag_ary as $key => $tagid) {
                    $postToTag[$key]['tags_id'] = $tagid;
                    $postToTag[$key]['post_id'] = $postCat->post_id;
                }
                $postCat->postToTag()->sync($postToTag);
            }





            // if (!empty($tag_ary)) {
            //     foreach ($tag_ary as $key => $value) {
            //         $postToTag = PostToTag::updateOrCreate(
            //             [
            //                 'post_id' => $postCat->post_id,
            //                 'tags_id' => $value,
            //             ],
            //             // [
            //             //     // 'post_id' => $postCat->post_id,
            //             //     'tags_id' => $value,

            //             // ]
            //         );
            //     }
            // }




            // store post description

            // detach info
            //   PostDescriptions::where('post_id', $post_id)->delete();

            foreach (ApiHelper::allSupportLang() as $key => $value) {

                $post_title = "post_title_" . $value->languages_id;
                $post_content = "post_content_" . $value->languages_id;
                $post_excerpt = "post_excerpt_" . $value->languages_id;
                $seometa_title = "seometa_title_" . $value->languages_id;
                $seometa_desc = "seometa_desc_" . $value->languages_id;

                if ($value->languages_code == 'en') {
                    $page_data = Posts::find($post_id);

                    if (empty($request->slug)) {
                        $page_data->slug = Str::slug($request->$post_title);
                    } else {

                        $page_data->slug = $request->slug;
                    }

                    $page_data->save();
                }

                $Postdes = PostDescriptions::updateOrCreate([
                    'post_id' => $post_id,
                    'languages_id' => $value->languages_id,
                ], [
                    'post_title' => $request->$post_title,
                    'post_content' => $request->$post_content,
                    'post_excerpt' => $request->$post_excerpt,
                    'languages_id' => $value->languages_id,
                ]);

                if (!empty($request->$seometa_title) || !empty($request->$seometa_desc)) {
                    // update or create  seo meta details
                    SeoMeta::updateOrCreate([
                        'page_type' => 4,
                        'reference_id' => $Postdes->post_description,
                        'language_id' => $value->languages_id,
                    ], [
                        'seometa_title' => $request->$seometa_title, 'seometa_desc' => $request->$seometa_desc,
                    ]);
                }
            } //end foreach
        } // end if

        else {

            foreach (ApiHelper::allSuperSupportLang() as $key => $value) {

                //validation check
                $validator = Validator::make(
                    $request->all(),
                    [
                        'post_title_' . $value->languages_id => 'required',
                        'post_content_' . $value->languages_id => 'required',
                        'post_excerpt_' . $value->languages_id => 'required',
                    ],
                    [

                        'post_title_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'POST_TITLE_REQUIRED',
                        'post_content_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'POST_CONTENT_REQUIRED',
                        'post_excerpt_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'POST_EXCERPT_REQUIRED',

                    ]

                );
                if ($validator->fails()) {
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
                }
            }

            // store posts
            $saveData = $request->only(['status', 'banner_image', 'created_at', 'thumbnail_image', 'author_id']);
            $saveData['slug'] = "";

            if ($saveData['banner_image'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['banner_image'], 1, 'post', '', false);
            }

            if ($saveData['thumbnail_image'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['thumbnail_image'], 1, 'post/thumb', '', false);
            }
            //  $saveData['created_by'] = ApiHelper::get_user_id_from_token($api_token);

            $cat = LandingPost::where('post_id', $post_id)->update($saveData);




            // deattach category
            $postCat = LandingPost::find($post_id);
            //  $postCat->post_to_categories()->detach();

            // attach category to post
            if (!empty($request->category_id)) {
                // for post to category
                $postToCategory = [];
                foreach ($request->category_id as $key => $catid) {
                    $postToCategory[$key]['category_id'] = $catid;
                    $postToCategory[$key]['post_id'] = $postCat->post_id;
                }
                $postCat->post_to_categories()->sync($postToCategory);
            }



            $tag_ary = explode(',', $request->tags_id);
            //     $tag_ary =  $request->tags_id;
            //$postCat->postToTag()->detach();

            // attach category to post
            if (!empty($tag_ary)) {
                // for post to category
                $postToTag = [];
                foreach ($tag_ary as $key => $tagid) {
                    $postToTag[$key]['tags_id'] = $tagid;
                    $postToTag[$key]['post_id'] = $postCat->post_id;
                }
                $postCat->postToTag()->sync($postToTag);
            }








            // store post description

            foreach (ApiHelper::allSuperSupportLang() as $key => $value) {

                $post_title = "post_title_" . $value->languages_id;
                $post_content = "post_content_" . $value->languages_id;
                $post_excerpt = "post_excerpt_" . $value->languages_id;
                $seometa_title = "seometa_title_" . $value->languages_id;
                $seometa_desc = "seometa_desc_" . $value->languages_id;

                if ($value->languages_code == 'en') {
                    $page_data = LandingPost::find($post_id);
                    if (empty($request->slug)) {
                        $page_data->slug = Str::slug($request->$post_title);
                    } else {

                        $page_data->slug = $request->slug;
                    }

                    $page_data->save();
                }

                $Postdes = LandingPostDescription::updateOrCreate([
                    'post_id' => $post_id,
                    'languages_id' => $value->languages_id,
                ], [
                    'post_title' => $request->$post_title,
                    'post_content' => $request->$post_content,
                    'post_excerpt' => $request->$post_excerpt,
                    'languages_id' => $value->languages_id,
                ]);

                if (!empty($request->$post_title) || !empty($request->$post_content)) {
                    // update landing seo meta
                    LandingSeoMeta::updateOrCreate([
                        'page_type' => 4,
                        'reference_id' => $Postdes->post_description,
                        'language_id' => $value->languages_id,
                    ], [
                        'seometa_title' => $request->$seometa_title, 'seometa_desc' => $request->$seometa_desc,
                    ]);
                }
            }
        }

        if ($cat) {
            return ApiHelper::JSON_RESPONSE(true, $saveData, 'SUCCESS_POST_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_POST_UPDATE');
        }
    }

    public function destroy(Request $request)
    {
        $api_token = $request->api_token;

        $userType = ApiHelper::userType($api_token);


        if ($userType == 'subscriber') {

            // $status = Posts::with('descriptionDetails', 'post_to_categories', 'postToTag')->where('post_id', $request->post_id)->delete();
            $data = Posts::with('descriptionDetails', 'post_to_categories', 'postToTag')->where('post_id', $request->post_id)->first();


            if (!empty($data)) {

                $data->descriptionDetails()->delete();
                $data->post_to_categories()->detach();
                $data->postToTag()->detach();
                $data = Posts::where('post_id', $request->post_id)->delete();
            }
        } else {

            //  $data = LandingPost::where('post_id', $request->post_id)->delete();
            $data = LandingPost::with('descriptionDetails', 'post_to_categories', 'postToTag')->where('post_id', $request->post_id)->first();
            if (!empty($data)) {

                $data->descriptionDetails()->delete();
                $data->post_to_categories()->detach();
                $data->postToTag()->detach();
                $data = LandingPost::where('post_id', $request->post_id)->delete();
            }
        }

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_POST_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_POST_DELETE');
        }
    }

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token;

        $userType = ApiHelper::userType($api_token);

        if ($userType == 'subscriber') {

            $post_id = $request->post_id;
            $sub_data = Posts::find($post_id);
            $sub_data->status = ($sub_data->status == 0) ? 1 : 0;
            $sub_data->save();
        } else {
            $post_id = $request->post_id;
            $sub_data = LandingPost::find($post_id);
            $sub_data->status = ($sub_data->status == 0) ? 1 : 0;
            $sub_data->save();
        }

        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }

    public function view(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        if ($userType == 'subscriber') {

            $response = Posts::with('descriptionDetails')->find($request->post_id);
        } else {

            $response = LandingPost::with('descriptionDetails')->find($request->post_id);
        }
        $language = (new self)->language_list($api_token);

        $res = [
            'data_list' => $response,
            'language' => $language

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }




    public function is_featured(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $post_id = $request->post_id;

        if ($userType == 'subscriber') {
            $infodata = Posts::find($post_id);
            $infodata->is_feature = ($infodata->is_feature == 0) ? 1 : 0;
            $infodata->save();
        } else {

            $infodata = LandingPost::find($post_id);
            $infodata->is_feature = ($infodata->is_feature == 0) ? 1 : 0;
            $infodata->save();
        }



        return ApiHelper::JSON_RESPONSE(true, $infodata, 'SUCCESS_IS_FEATURED_UPDATE');
    }
}
