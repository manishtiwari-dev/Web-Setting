<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Modules\WebsiteSetting\Models\FormData;
use Modules\WebsiteSetting\Models\FormField;
use Modules\WebsiteSetting\Models\Form;
use Modules\WebsiteSetting\Models\Super\LandingForm;
use Modules\WebsiteSetting\Models\Super\LandingFormField;
use Modules\WebsiteSetting\Models\Super\LandingFormData;
use Illuminate\Support\Str;

use ApiHelper;


class FormController extends Controller
{
    public $page = 'custom_form';
    public $landing_page = 'landing_custom_form';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    //This Function is used to show the list of form
    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $system_default = [];
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landing_page);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBy = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        /*Fetching plan data*/
        if ($userType == 'subscriber') {
            $data_query = Form::query();
        } else {
            $data_query = LandingForm::query();
        }


        /*Checking if search data is not empty*/
        if (!empty($search))
            $data_query = $data_query->where("form_name", "LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBy) && !empty($ASCTYPE)) {

            $data_query = $data_query->orderBy($sortBy, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('form_id', 'ASC');
        }


        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;

        $form_count = $data_query->count();

        $form_list = $data_query->skip($skip)->take($perPage)->get();




        if (!empty($form_list)) {

            $form_list = $form_list->map(function ($data) {
                $data->system_default = $data->system_default;
                $data->editable = 0;
                return $data;
            });
        } else {

            $super_query = LandingForm::query();
            if (!empty($super_query)) {

                if (!empty($search))
                    $super_query = $super_query
                        ->where("form_name", "LIKE", "%{$search}%");

                /* order by sorting */
                if (!empty($sortBy) && !empty($ASCTYPE)) {

                    $super_query = $super_query->orderBy($sortBy, $ASCTYPE);
                } else {
                    $super_query = $super_query->orderBy('form_id', 'ASC');
                }


                $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;

                $form_count = $super_query->count();

                $form_list = $super_query->skip($skip)->take($perPage)->get();


                $form_list = $form_list->map(function ($data) {
                    $data->system_default = $data->system_default;
                    $data->editable = 0;
                    return $data;
                });
            }
        }





        //   return ApiHelper::JSON_RESPONSE(true, $form_list, '');


        $res = [
            'data' => $form_list,
            'current_page' => $current_page,
            'total_records' => $form_count,
            'total_page' => ceil((int)$form_count / (int)$perPage),
            'per_page' => $perPage,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }



    public function validate_form_shortcode($shortcode, $i = 0)
    {

        if ($i)
            $update_shortcode = $shortcode . $i;
        else
            $update_shortcode = $shortcode;

        $shortCode_Data = Form::where('form_shortcode', $update_shortcode)->first();

        if (!empty($shortCode_Data)) {
            $i += 1;
            return $this->validate_form_shortcode($shortcode, $i);
        } else {
            return $update_shortcode;
        }
    }


    public function form_type(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $form_type = $request->form_type;

        if ($userType == 'subscriber') {
            //  Form
            $form_type = LandingForm::where('form_type', $form_type)->get();
            $form_type = $form_type->map(function ($data) {
                if (!empty($data->form_field)) {
                    $data->form_field = $data->form_field;
                }
                return $data;
            });
        } else {



            $form_type = LandingForm::where('form_type', $form_type)->get();
            $form_type = $form_type->map(function ($data) {
                if (!empty($data->form_field)) {
                    $data->form_field = $data->form_field;
                }
                return $data;
            });
        }





        return ApiHelper::JSON_RESPONSE(true, $form_type, '');
    }


    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        if ($userType == 'subscriber') {
            // store form 
            $saveData =  $request->only(['form_name', 'form_type']);
            $form = Form::create($saveData);

            // if (!empty($request->input('form_shortcode'))) {
            //     $form_shortcode = $this->validate_form_shortcode($request->input('form_shortcode'));
            //     $saveData['form_shortcode'] = $form_shortcode;
            //     $form = Form::create($saveData);
            // }

            // attach form field to form
            if ($request->has('form_field') && sizeof($request->form_field) > 0) {
                foreach ($request->form_field as $key => $formField) {
                    FormField::create([
                        'form_id' => $form->form_id,
                        'field_label' => $formField['field_label'],
                        'field_name' => \Str::slug($formField['field_label'], '-'),
                        'field_class' => $formField['field_class'],
                        'field_width' => isset($formField['field_width']) ? $formField['field_width'] : '',
                        'field_type' => $formField['field_type'],
                        'field_values' => isset($formField['field_values']) ? $formField['field_values'] : '',
                        'placeholder' => isset($formField['placeholder']) ? $formField['placeholder'] : '',
                        'sort_order' => isset($formField['sort_order']) ? $formField['sort_order'] : '',
                        'required' => isset($formField['required']) ? $formField['required'] : '',
                        'validation_msg' => isset($formField['validation_msg']) ? $formField['validation_msg'] : '',

                    ]);
                }
            }
        } else {


            // store form 
            $saveData =  $request->only(['form_name', 'form_type']);
            $form = LandingForm::create($saveData);


            // attach form field to form
            if ($request->has('form_field') && sizeof($request->form_field) > 0) {
                foreach ($request->form_field as $key => $formField) {
                    LandingFormField::create([
                        'form_id' => $form->form_id,
                        'field_label' => $formField['field_label'],
                        'field_name' => \Str::slug($formField['field_label'], '-'),
                        'field_class' => $formField['field_class'],
                        'field_width' => isset($formField['field_width']) ? $formField['field_width'] : '',
                        'field_type' => $formField['field_type'],
                        'field_values' => isset($formField['field_values']) ? $formField['field_values'] : '',
                        'placeholder' => isset($formField['placeholder']) ? $formField['placeholder'] : '',
                        'sort_order' => isset($formField['sort_order']) ? $formField['sort_order'] : '',
                        'required' => isset($formField['required']) ? $formField['required'] : '',
                        'validation_msg' => isset($formField['validation_msg']) ? $formField['validation_msg'] : '',

                    ]);
                }
            }
        }

        return ApiHelper::JSON_RESPONSE(true, $form, 'SUCCESS_FORM_ADD');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function edit(Request $request)
    {

        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {

            $response = Form::with('form_field')->find($request->form_id);
            if (!empty($response)) {
                $response->setRelation('form_field', $response->form_field()->orderBy('sort_order', 'ASC')->get());
            }
        } else {
            $response = LandingForm::with('form_field')->find($request->form_id);
            if (!empty($response)) {
                $response->setRelation('form_field', $response->form_field()->orderBy('sort_order', 'ASC')->get());
            }
        }


        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }

    //This Function is used to update the particular plan data
    public function update(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $form_id = $request->form_id;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        if ($userType == 'subscriber') {
            // store form 
            $saveData =  $request->only(['form_name', 'form_type', 'status']);
            Form::where('form_id', $form_id)->update($saveData);
            $form = Form::find($form_id);
            // attach form field to form
            FormField::where('form_id', $form_id)->delete();
            if ($request->has('form_field') && sizeof($request->form_field) > 0) {
                foreach ($request->form_field as $key => $formField) {
                    FormField::create([
                        'form_id' => $form->form_id,
                        // 'field_label' => $formField['field_label'],
                        // 'field_name' => \Str::slug($formField['field_label'], '-'),
                        // 'field_type' => $formField['field_type'],
                        // 'field_class' => $formField['field_class'],
                        // 'field_width' => $formField['field_width'],
                        // 'placeholder' => $formField['placeholder'],
                        // //  'validation_msg' => $formField['validation_msg'],
                        // 'field_values' => isset($formField['field_values']) ? $formField['field_values'] : '',
                        // 'sort_order' => $formField['sort_order'],
                        // 'required' => $formField['required'],
                        'field_label' => $formField['field_label'],
                        'field_name' => \Str::slug($formField['field_label'], '-'),
                        'field_class' => $formField['field_class'],
                        'field_width' => isset($formField['field_width']) ? $formField['field_width'] : '',
                        'field_type' => $formField['field_type'],
                        'field_values' => isset($formField['field_values']) ? $formField['field_values'] : '',
                        'placeholder' => isset($formField['placeholder']) ? $formField['placeholder'] : '',
                        'sort_order' => isset($formField['sort_order']) ? $formField['sort_order'] : '',
                        'required' => isset($formField['required']) ? $formField['required'] : '',
                        'validation_msg' => isset($formField['validation_msg']) ? $formField['validation_msg'] : '',


                    ]);
                }
            }
        } else {

            // store form 
            $saveData =  $request->only(['form_name', 'form_type', 'status']);
            LandingForm::where('form_id', $form_id)->update($saveData);
            $form = LandingForm::find($form_id);
            // attach form field to form
            LandingFormField::where('form_id', $form_id)->delete();
            if ($request->has('form_field') && sizeof($request->form_field) > 0) {
                foreach ($request->form_field as $key => $formField) {
                    LandingFormField::create([
                        'form_id' => $form->form_id,
                        'field_label' => $formField['field_label'],
                        'field_name' => \Str::slug($formField['field_label'], '-'),
                        'field_class' => $formField['field_class'],
                        'field_width' => isset($formField['field_width']) ? $formField['field_width'] : '',
                        'field_type' => $formField['field_type'],
                        'field_values' => isset($formField['field_values']) ? $formField['field_values'] : '',
                        'placeholder' => isset($formField['placeholder']) ? $formField['placeholder'] : '',
                        'sort_order' => isset($formField['sort_order']) ? $formField['sort_order'] : '',
                        'required' => isset($formField['required']) ? $formField['required'] : '',
                        'validation_msg' => isset($formField['validation_msg']) ? $formField['validation_msg'] : '',


                    ]);
                }
            }
        }




        return ApiHelper::JSON_RESPONSE(true, $saveData, 'SUCCESS_FORM_UPDATE');
    }



    public function destroy(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        if ($userType == 'subscriber') {
            $DETAIL = Form::with('form_field')->where('form_id', $request->form_id)->first();
            $form_data = FormData::where('form_id', $DETAIL->form_id)->first();

            if (empty($form_data->form_id)) {
                if (!empty($DETAIL)) $DETAIL->form_field()->delete();   // relation data delete

                $DETAIL = Form::where('form_id', $request->form_id)->delete();
            } else {
                return ApiHelper::JSON_RESPONSE(false, [], 'UNABLE_TO_FORM_DELETE');
            }
        } else {

            $DETAIL = LandingForm::with('form_field')->where('form_id', $request->form_id)->first();
            $form_data = LandingFormData::where('form_id', $DETAIL->form_id)->first();

            if (empty($form_data->form_id)) {
                if (!empty($DETAIL)) $DETAIL->form_field()->delete();   // relation data delete

                $DETAIL = LandingForm::where('form_id', $request->form_id)->delete();
            } else {
                return ApiHelper::JSON_RESPONSE(false, [], 'UNABLE_TO_FORM_DELETE');
            }
        }

        if ($DETAIL) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_FORM_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_FORM_DELETE');
        }
    }


    //This Function is used to get the change the form status
    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        if ($userType == 'subscriber') {
            $infoData = Form::find($request->form_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        } else {

            $infoData = LandingForm::find($request->form_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        }

        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_STATUS_UPDATE');
    }
}
