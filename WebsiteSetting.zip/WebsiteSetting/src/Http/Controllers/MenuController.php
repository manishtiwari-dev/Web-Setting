<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use ApiHelper;
use Modules\WebsiteSetting\Models\Menu;
use Modules\WebsiteSetting\Models\MenuGroup;
use Modules\WebsiteSetting\Models\MenuDetails;
use Modules\WebsiteSetting\Models\WebPages;
use Modules\Ecommerce\Models\Category;
use Modules\Listing\Models\BusinessCategory;
use Modules\WebsiteSetting\Models\Super\LandingMenuGroup;
use Modules\WebsiteSetting\Models\Super\LandingMenu;
use Modules\WebsiteSetting\Models\Super\LandingMenuDetails;
use Modules\WebsiteSetting\Models\Super\LandingPages;


class MenuController extends Controller
{
    public $page = 'menu_setting';
    public $landingpage = 'landing_menu_setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    public function list(Request $request)
    {
        $cName = $type = '';

        $language = $request->language;
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;


        if ($userType == 'subscriber') {
            $data_query = Menu::with(['menuDetails' => function ($query) {
                $query->where('languages_id', 1);
            }])->where('group_id', $request->group_id)->where('parent_id', 0);



            /* order by sorting */
            if (!empty($sortBY) && !empty($ASCTYPE)) {
                $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
            } else {
                $data_query = $data_query->orderBy('sort_order', 'ASC');
            }
            $data_list = $data_query->get();


            $data_list = $data_list->map(function ($data)  use ($language) {
                $cate = $data->bannerGroup()->first();
                $data->group_name = ($cate == null) ? '' : $cate->group_name;
                $menu_details = $data->menuDetails()->where('languages_id', 1)->first();
                $data->menuName =  ($menu_details == null) ? '' : $menu_details->menu_name;

                // getting sub menu
                $sub_menu = Menu::with(['menuDetails' => function ($query) {
                    $query->where('languages_id', 1);
                }])->where('parent_id', $data->menu_id)->get();
                if (!empty($sub_menu)) {
                    if (sizeof($sub_menu) > 0) {
                        $sub_menu = $sub_menu->map(function ($sub) use ($language) {



                            //getting sub sub menu
                            $sub_sub_menu = Menu::where('parent_id', $sub->menu_id)->get();
                            if (sizeof($sub_sub_menu) > 0) {
                                $sub_sub_menu = $sub_sub_menu->map(function ($sub) use ($language) {
                                    $sub->sub_sub_menu_details = $sub->menuDetails()->where('languages_id', ApiHelper::getLangid($language))->first();

                                    //   $sub->menu_name = ($submenu == null) ? '' : $submenu->menu_name;

                                    return $sub;
                                });
                            }

                            $sub->sub_sub_menu = ($sub_sub_menu == null) ? '' : $sub_sub_menu;

                            return $sub;
                        });
                    }
                }


                $data->sub_menu =  ($sub_menu == null) ? '' : $sub_menu;
                return $data;
            });



            if ($request->has('group_id')) {
                //getting category Name
                $grpName = MenuGroup::where('group_id', $request->group_id)->first();
                $cName = !empty($grpName) ? $grpName->group_name : '';
            }

            if ($request->has('group_id')) {
                //getting category Name
                $typeName = Menu::where('group_id', $request->group_id)->first();
                $type = !empty($typeName) ? $typeName->menu_type : '';
            }
        } else {

            $data_query = LandingMenu::with(['menuDetails' => function ($query) {
                $query->where('languages_id', 1);
            }])->where('group_id', $request->group_id)->where('parent_id', 0);



            /* order by sorting */
            if (!empty($sortBY) && !empty($ASCTYPE)) {
                $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
            } else {
                $data_query = $data_query->orderBy('sort_order', 'ASC');
            }
            $data_list = $data_query->get();

            $data_list = $data_list->map(function ($data)  use ($language) {
                $cate = $data->bannerGroup()->first();
                $data->group_name = ($cate == null) ? '' : $cate->group_name;
                $menu_details = $data->menuDetails()->where('languages_id', 1)->first();
                $data->menuName =  ($menu_details == null) ? '' : $menu_details->menu_name;

                // getting sub menu
                $sub_menu = LandingMenu::with(['menuDetails' => function ($query) {
                    $query->where('languages_id', 1);
                }])->where('parent_id', $data->menu_id)->get();
                if (!empty($sub_menu)) {
                    if (sizeof($sub_menu) > 0) {
                        $sub_menu = $sub_menu->map(function ($sub) use ($language) {

                            //getting sub sub menu
                            $sub_sub_menu = LandingMenu::where('parent_id', $sub->menu_id)->get();
                            if (sizeof($sub_sub_menu) > 0) {
                                $sub_sub_menu = $sub_sub_menu->map(function ($sub) use ($language) {
                                    $sub->sub_sub_menu_details = $sub->menuDetails()->where('languages_id', ApiHelper::getLangid($language))->first();

                                    //   $sub->menu_name = ($submenu == null) ? '' : $submenu->menu_name;

                                    return $sub;
                                });
                            }

                            $sub->sub_sub_menu = ($sub_sub_menu == null) ? '' : $sub_sub_menu;

                            return $sub;
                        });
                    }
                }


                $data->sub_menu = ($sub_menu == null) ? '' : $sub_menu;
                return $data;
            });



            if ($request->has('group_id')) {
                //getting category Name
                $grpName = LandingMenuGroup::where('group_id', $request->group_id)->first();
                $cName = !empty($grpName) ? $grpName->group_name : '';
            }

            if ($request->has('group_id')) {
                //getting category Name
                $typeName = LandingMenu::where('group_id', $request->group_id)->first();
                $type = !empty($typeName) ? $typeName->menu_type : '';
            }
        }





        $res = [
            'data_list' => $data_list,
            'group_name' => $cName,
            'menu_type' => $type,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }



    public function create(Request $request)
    {
        $services_data = $category_data = [];
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {

            $industry_id = ApiHelper::get_industry_id_by_api_token($api_token);
            $module_status_ecom =  ApiHelper::check_module_status_by_industryid($industry_id, '6'); // 6= ECom
            if ($module_status_ecom)
                $category_data = Category::where('status', 1)->get();

            $module_status_service =  ApiHelper::check_module_status_by_industryid($industry_id, '17'); // 17= serice
            if ($module_status_service)
                $services_data = BusinessCategory::all();

            $page_data = WebPages::select('pages_slug as label', 'pages_id as value')->where('status', 1)->get();

            $parent_type = Menu::with(['menuDetails' => function ($query) {
                $query->where('languages_id', 1);
            }])->where('group_id', $request->group_id)->orderBy('sort_order', 'ASC')->get();

            if ($request->has('group_id')) {
                //getting category Name
                $menuType = Menu::where('group_id', $request->group_id)->first();
                $cName = !empty($menuType) ? $menuType->menu_type : '';
            }
            $language = ApiHelper::allSupportLang();
        } else {

            // $category_data = Category::where('status', 1)->get();
            // $services_data = BusinessCategory::all();

            $page_data = LandingPages::select('pages_slug as label', 'pages_id as value')->where('status', 1)->get();

            $parent_type = LandingMenu::with(['menuDetails' => function ($query) {
                $query->where('languages_id', 1);
            }])->where('group_id', $request->group_id)->orderBy('sort_order', 'ASC')->get();

            if ($request->has('group_id')) {
                //getting category Name
                $menuType = LandingMenu::where('group_id', $request->group_id)->first();
                $cName = !empty($menuType) ? $menuType->menu_type : '';
            }
            $language = ApiHelper::allSuperSupportLang();
        }





        $data = [
            'page_data' => $page_data,
            'category_data' => $category_data,
            'services_data' => $services_data,
            'parent_type' => $parent_type,
            'menu_type' => $cName,
            'language' => $language,
        ];

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, '');
        else
            return ApiHelper::JSON_RESPONSE(false, [], '');
    }

    public function store(Request $request)
    {
        $menudetails = '';
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        if ($userType == 'subscriber') {

            //validation check

            foreach (ApiHelper::allSupportLang() as $key => $value) {

                //validation check
                $validator = Validator::make(
                    $request->all(),
                    [
                        'menu_name_' . $value->languages_id => 'required',
                    ],
                    [
                        'menu_name_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'MENU_NAME_REQUIRED',
                    ]

                );
                if ($validator->fails()) {
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
                }
            }
            $menu_data = $request->only(['group_id',  'menu_type', 'menu_link', 'parent_id', 'menu_ref_id', 'menu_icon']);
            $max_sortOrder =  Menu::max('sort_order');
            $sort_order = $max_sortOrder + 1;
            $menu_data['sort_order'] = $sort_order;

            if ($request->has("menu_icon") && !empty($request->menu_icon)) {
                ApiHelper::image_upload_with_crop($api_token, $menu_data['menu_icon'], 1, 'menuIcon', '', false);
            }
            $data = Menu::create($menu_data);
            //    return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_MENU_ADD');
            $menudetails = '';
            foreach (ApiHelper::allSupportLang() as $key => $value) {

                $menu_name = "menu_name_" . $value->languages_id;
                $menu_label = "menu_label_" . $value->languages_id;

                //     return ApiHelper::JSON_RESPONSE(true, $menu_name, 'SUCCESS_MENU_ADD');
                if ($data->menu_id) {
                    $menudetails = MenuDetails::create([
                        'menu_id' => $data->menu_id,
                        'languages_id' => $value->languages_id,
                        'menu_name' => $request->$menu_name,
                        // 'menu_icon' =>    $menu_icon,
                        'menu_label' =>  $request->$menu_label,


                    ]);
                }
            }
        } else {

            //validation check

            foreach (ApiHelper::allSuperSupportLang() as $key => $value) {

                //validation check
                $validator = Validator::make(
                    $request->all(),
                    [
                        'menu_name_' . $value->languages_id => 'required',
                    ],
                    [
                        'menu_name_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'MENU_NAME_REQUIRED',
                    ]

                );
                if ($validator->fails()) {
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
                }
            }
            $menu_data = $request->only(['group_id',  'menu_type', 'menu_link', 'parent_id', 'menu_ref_id', 'menu_icon']);
            $max_sortOrder =  LandingMenu::max('sort_order');
            $sort_order = $max_sortOrder + 1;
            $menu_data['sort_order'] = $sort_order;

            if ($request->has("menu_icon") && !empty($request->menu_icon)) {
                ApiHelper::image_upload_with_crop($api_token, $menu_data['menu_icon'], 1, 'menuIcon', '', false);
            }
            $data = LandingMenu::create($menu_data);
            $menudetails = '';
            foreach (ApiHelper::allSuperSupportLang() as $key => $value) {

                $menu_name = "menu_name_" . $value->languages_id;
                $menu_label = "menu_label_" . $value->languages_id;

                //     return ApiHelper::JSON_RESPONSE(true, $menu_name, 'SUCCESS_MENU_ADD');
                if ($data->menu_id) {
                    $menudetails = LandingMenuDetails::create([
                        'menu_id' => $data->menu_id,
                        'languages_id' => $value->languages_id,
                        'menu_name' => $request->$menu_name,
                        // 'menu_icon' =>    $menu_icon,
                        'menu_label' =>  $request->$menu_label,


                    ]);
                }
            }
        }





        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_MENU_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_MENU_ADD');
    }

    public function edit(Request $request)
    {
        $services_data = $category_data = [];
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $industry_id = ApiHelper::get_industry_id_by_api_token($api_token);
            $module_status_ecom =  ApiHelper::check_module_status_by_industryid($industry_id, '6'); // 6= 
            if ($module_status_ecom)
                $category_data = Category::where('status', 1)->get();
            //  $category_data = Category::select('categories_slug as label', 'categories_id as value')->where('status', 1)->get();
            $module_status_service =  ApiHelper::check_module_status_by_industryid($industry_id, '17'); // 17= serice
            if ($module_status_service)
                $services_data = BusinessCategory::all();
            // $page_data = WebPages::where('status', 1)->get();
            $page_data = WebPages::select('pages_slug as label', 'pages_id as value')->where('status', 1)->get();
            $parent_type = Menu::with('menuDetails')->where('group_id', $request->group_id)->orderBy('sort_order', 'ASC')->get();

            //list menu
            $data_list = Menu::with('menuDetails')->where('menu_id', $request->menu_id)->get();
            if (!empty($data_list)) {

                $data_list = $data_list->map(function ($data)  use ($industry_id) {
                    $menu_details = $data->menuDetails()->where('languages_id', 1)->first();

                    if (!empty($data->menu_icon)) {
                        $data->menu_icon_url = ApiHelper::getFullImageUrl($data->menu_icon, 'index-list');
                    }

                    if (!empty($data->menu_ref_id))
                        // return ApiHelper::JSON_RESPONSE(true, $data->currency, '');
                        $data->selected_pages = WebPages::select('pages_slug as label', 'pages_id as value')->where('pages_id', $data->menu_ref_id)->get();
                    $data->selected_pages =  $data->selected_pages ==  '' ? [''] :  $data->selected_pages;


                    // $data->selected_pages = WebPages::select('pages_slug as label', 'pages_id as value')->whereRaw('pages_id IN(' . $data->menu_ref_id . ') ')->get();

                    $module_status_ecom =  ApiHelper::check_module_status_by_industryid($industry_id, '6'); // 6= 
                    if ($module_status_ecom)
                        $data->selected_category = Category::select('categories_slug as label', 'categories_id as value')->whereRaw('categories_id IN(' . $data->menu_ref_id . ') ')->get();


                    return $data;
                });
            }
            $language = ApiHelper::allSupportLang();
        } else {


            $page_data = LandingPages::select('pages_slug as label', 'pages_id as value')->where('status', 1)->get();
            $parent_type = LandingMenu::with('menuDetails')->where('group_id', $request->group_id)->orderBy('sort_order', 'ASC')->get();

            //list menu
            $data_list = LandingMenu::with('menuDetails')->where('menu_id', $request->menu_id)->get();
            if (!empty($data_list)) {

                $data_list = $data_list->map(function ($data) {
                    $menu_details = $data->menuDetails()->where('languages_id', 1)->first();

                    if (!empty($data->menu_icon)) {
                        $data->menu_icon_url = ApiHelper::getFullImageUrl($data->menu_icon, 'index-list');
                    }

                    if (!empty($data->menu_ref_id))
                        // return ApiHelper::JSON_RESPONSE(true, $data->currency, '');
                        $data->selected_pages = LandingPages::select('pages_slug as label', 'pages_id as value')->where('pages_id', $data->menu_ref_id)->get();
                    $data->selected_pages =  $data->selected_pages ==  '' ? [''] :  $data->selected_pages;



                    return $data;
                });
            }
            $language = ApiHelper::allSuperSupportLang();
        }

        $res = [
            'data_list' => $data_list,
            'page_data' => $page_data,
            'category_data' => $category_data,
            'services_data' => $services_data,
            'parent_type' => $parent_type,
            'language' => $language,
            //  'selected_menu_list' => $selected_menu_list
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function update(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        if ($userType == 'subscriber') {
            foreach (ApiHelper::allSupportLang() as $key => $value) {

                //validation check
                $validator = Validator::make(
                    $request->all(),
                    [
                        'menu_name_' . $value->languages_id => 'required',
                    ],
                    [
                        'menu_name_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'MENU_NAME_REQUIRED',
                    ]

                );
                if ($validator->fails()) {
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
                }
            }

            $menu_update_data = $request->only(['group_id', 'menu_name', 'menu_type', 'menu_link', 'status', 'sort_order', 'parent_id', 'menu_ref_id', 'menu_icon']);

            if ($request->has("menu_icon") && !empty($request->menu_icon)) {
                ApiHelper::image_upload_with_crop($api_token, $menu_update_data['menu_icon'], 1, 'menuIcon', '', false);
            }

            $data = Menu::where('menu_id', $request->menu_id)->update($menu_update_data);

            foreach (ApiHelper::allSupportLang() as $key => $value) {
                $menu_name =  $menu_label = '';
                $menu_name = "menu_name_" . $value->languages_id;
                $menu_label = "menu_label_" . $value->languages_id;
                MenuDetails::where('menu_id', $request->menu_id)->where('languages_id', $value->languages_id)->update(
                    [
                        'menu_name' => $request->$menu_name,
                        'menu_label' => $request->$menu_label,
                        'menu_id' => $request->menu_id,
                        'languages_id' => $value->languages_id,
                    ]
                );
            } //end foreach

        } else {

            foreach (ApiHelper::allSuperSupportLang() as $key => $value) {

                //validation check
                $validator = Validator::make(
                    $request->all(),
                    [
                        'menu_name_' . $value->languages_id => 'required',
                    ],
                    [
                        'menu_name_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'MENU_NAME_REQUIRED',
                    ]

                );
                if ($validator->fails()) {
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
                }
            }

            $menu_update_data = $request->only(['group_id', 'menu_name', 'menu_type', 'menu_link', 'status', 'sort_order', 'parent_id', 'menu_ref_id', 'menu_icon']);

            if ($request->has("menu_icon") && !empty($request->menu_icon)) {
                ApiHelper::image_upload_with_crop($api_token, $menu_update_data['menu_icon'], 1, 'menuIcon', '', false);
            }

            $data = LandingMenu::where('menu_id', $request->menu_id)->update($menu_update_data);

            foreach (ApiHelper::allSuperSupportLang() as $key => $value) {
                $menu_name =  $menu_label = '';
                $menu_name = "menu_name_" . $value->languages_id;
                $menu_label = "menu_label_" . $value->languages_id;


                //     'languages_id' => $value->languages_id,
                LandingMenuDetails::where('menu_id', $request->menu_id)->where('languages_id', $value->languages_id)->update(
                    [
                        'menu_name' => $request->$menu_name,
                        'menu_label' => $request->$menu_label,
                        'menu_id' => $request->menu_id,
                        'languages_id' => $value->languages_id,
                    ]
                );
            } //end foreach


        }



        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_MENU_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_MENU_UPDATE');
    }


    public function destroy(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        if ($userType == 'subscriber') {
            $status = Menu::where('menu_id', $request->menu_id)->delete();
        } else {
            $status = LandingMenu::where('menu_id', $request->menu_id)->delete();
        }


        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_MENU_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_MENU_DELETE');
        }
    }

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $update_id = $request->update_id;

        if ($userType == 'subscriber') {
            $sub_data = Menu::find($update_id);
            $sub_data->status = ($sub_data->status == 0) ? 1 : 0;
            $sub_data->save();
        } else {

            $sub_data = LandingMenu::find($update_id);
            $sub_data->status = ($sub_data->status == 0) ? 1 : 0;
            $sub_data->save();
        }



        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }

    public function sortOrder(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $menu_id = $request->menu_id;
        $sort_order = $request->sort_order;
        if ($userType == 'subscriber') {
            $infoData =  Menu::find($menu_id);
            if (empty($infoData)) {
                $infoData = new Menu();
                $infoData->menu_id = $menu_id;
                $infoData->sort_order = $sort_order;
                $infoData->status = 1;

                $infoData->save();
            } else {
                $infoData->sort_order = $sort_order;
                $infoData->save();
            }
        } else {
            $infoData =  LandingMenu::find($menu_id);
            if (empty($infoData)) {
                $infoData = new LandingMenu();
                $infoData->menu_id = $menu_id;
                $infoData->sort_order = $sort_order;
                $infoData->status = 1;

                $infoData->save();
            } else {
                $infoData->sort_order = $sort_order;
                $infoData->save();
            }
        }




        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_SORT_ORDER_UPDATE');
    }
}
