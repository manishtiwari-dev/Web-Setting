<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use ApiHelper;
use App\Http\Controllers\Controller;
use App\Models\Language;
use App\Models\UserBusiness;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Modules\Ecommerce\Models\SeoMeta;
use Modules\WebsiteSetting\Models\Super\LandingPages;
use Modules\WebsiteSetting\Models\Super\LandingPagesDescription;
use Modules\WebsiteSetting\Models\Super\LandingSeoMeta;
use Modules\WebsiteSetting\Models\WebPages;
use Modules\WebsiteSetting\Models\WebPagesDescription;

class PagesController extends Controller
{

    public $page = 'page_setting';
    public $landingpage = 'super_page_setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int) $request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        $language = $request->language;

        if ($userType == 'subscriber') {

            $data_query = WebPages::with('page_description');
        } else {

            $data_query = LandingPages::with('page_description');
        }

        if (!empty($search)) {
            $data_query = $data_query->where("pages_slug", "LIKE", "%{$search}%")
                ->orWhereHas('page_description', function ($data_query) use ($search) {
                    $data_query->where("pages_title", "LIKE", "%{$search}%");
                });
        }


        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('pages_id', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int) ($current_page - 1) * $perPage;

        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $data_list = $data_list->map(function ($data) use ($language) {

            $pagese = $data->page_description()->where('language_id', ApiHelper::getLangid($language))->first();

            $data->pages_title = ($pagese == null) ? '' : $pagese->pages_title;
            $data->pages_content = ($pagese == null) ? '' : $pagese->pages_content;
            //   $data->status = ($data->status == 1) ? "active" : "deactive";

            return $data;
        });


        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int) $user_count / (int) $perPage),
            'per_page' => $perPage,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function language_list($api_token)
    {
        $api_token = $api_token;

        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {

            $language = ApiHelper::allSupportLang();
        } else {

            $language = ApiHelper::allSuperSupportLang();
        }

        return $language;
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {

        $api_token = $request->api_token;
        $api_token = $request->api_token;
        $language = (new self)->language_list($api_token);
        $res = [
            'language' => $language

        ];


        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        if ($userType == 'subscriber') {

            foreach (ApiHelper::allSupportLang() as $key => $value) {

                //validation check
                $validator = Validator::make(
                    $request->all(),
                    [
                        'pages_title_' . $value->languages_id => 'required',
                    ],
                    [
                        'pages_title_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'PAGE_TITLE_REQUIRED',
                    ]

                );
                if ($validator->fails()) {
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
                }
            }

            // store pages
            $saveData = $request->only(['noindex']);
            $pageSlug = WebPages::where('pages_slug',  $request->pages_slug)->first();
            if (empty($pageSlug)) {
                $saveData['pages_slug'] = $request->pages_slug;
            } else {
                return ApiHelper::JSON_RESPONSE(false, [], 'PAGES_SLUG_ALREADY_EXISTS');
                // $saveData['pages_slug'] = "";
            }


            //  $saveData['pages_slug'] = "";
            $max_sortOrder = WebPages::max('sort_order');
            $sort_order = $max_sortOrder + 1;
            $saveData['sort_order'] = $sort_order;
            $pages = WebPages::create($saveData);

            // store pages details
            foreach (ApiHelper::allSupportLang() as $key => $value) {

                $pages_title = "pages_title_" . $value->languages_id;
                $pages_content = "pages_content_" . $value->languages_id;
                $seometa_title = "seometa_title_" . $value->languages_id;
                $seometa_desc = "seometa_desc_" . $value->languages_id;

                if ($value->languages_code == 'en') {
                    $page_data = WebPages::find($pages->pages_id);


                    // $pageSlug = WebPages::where('pages_slug',  $request->pages_slug)->first();
                    // if (empty($pageSlug)) {
                    //     $page_data->pages_slug = $request->pages_slug;
                    //     $page_data->save();
                    // } else {
                    //     return ApiHelper::JSON_RESPONSE(false, [], 'PAGES_SLUG_ALREADY_EXISTS');
                    // }



                    // if (empty($request->pages_slug)) {
                    //     $page_data->pages_slug = Str::slug($request->$pages_title);
                    // } else {
                    //     $page_data->pages_slug = $request->pages_slug;
                    // }

                    // $page_data->save();
                }

                $Postdesc = WebPagesDescription::create([
                    'pages_id' => $pages->pages_id,
                    'pages_title' => $request->$pages_title,
                    'pages_content' => $request->$pages_content,
                    'language_id' => $value->languages_id,
                ]);

                if (!empty($request->$seometa_title) || !empty($request->$seometa_desc)) {
                    SeoMeta::create([
                        'page_type' => 3,
                        'reference_id' => $Postdesc->page_description_id,
                        'language_id' => $value->languages_id,
                        'seometa_title' => $request->$seometa_title,
                        'seometa_desc' => $request->$seometa_desc,
                    ]);
                }
            }
        } else {

            foreach (ApiHelper::allSuperSupportLang() as $key => $value) {

                //validation check
                $validator = Validator::make(
                    $request->all(),
                    [
                        'pages_title_' . $value->languages_id => 'required',
                    ],
                    [
                        'pages_title_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'PAGE_TITLE_REQUIRED',
                    ]

                );
                if ($validator->fails()) {
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
                }
            }
            $saveData = $request->only(['noindex']);

            $saveData['pages_slug'] = "";
            $max_sortOrder = LandingPages::max('sort_order');
            $sort_order = $max_sortOrder + 1;
            $saveData['sort_order'] = $sort_order;
            $pageSlug = LandingPages::where('pages_slug',  $request->pages_slug)->first();
            if (empty($pageSlug)) {
                $saveData['pages_slug'] = $request->pages_slug;
            } else {
                return ApiHelper::JSON_RESPONSE(false, [], 'PAGES_SLUG_ALREADY_EXISTS');
                // $saveData['pages_slug'] = "";
            }
            $pages = LandingPages::create($saveData);

            // store pages details
            foreach (ApiHelper::allSuperSupportLang() as $key => $value) {
                $pages_title = "pages_title_" . $value->languages_id;
                $pages_content = "pages_content_" . $value->languages_id;
                $seometa_title = "seometa_title_" . $value->languages_id;
                $seometa_desc = "seometa_desc_" . $value->languages_id;
                // if ($value->languages_code == 'en') {
                //     $page_data = LandingPages::find($pages->pages_id);

                //     // $pageSlug = LandingPages::where('pages_slug',  $request->pages_slug)->first();
                //     // if (empty($pageSlug)) {
                //     //     $page_data->pages_slug = $request->pages_slug;
                //     //     $page_data->save();
                //     // } else {
                //     //     return ApiHelper::JSON_RESPONSE(false, [], 'PAGES_SLUG_ALREADY_EXISTS');
                //     // }


                //     // $page_data->pages_slug = Str::slug($request->$pages_title);
                //     // $page_data->save();
                // }

                $Postdesc = LandingPagesDescription::create([
                    'pages_id' => $pages->pages_id,
                    'pages_title' => $request->$pages_title,
                    'pages_content' => $request->$pages_content,
                    'language_id' => $value->languages_id,
                ]);

                if (!empty($request->$seometa_title) || !empty($request->$seometa_desc)) {
                    LandingSeoMeta::create([
                        'page_type' => 2,
                        'reference_id' => $Postdesc->page_description_id,
                        'language_id' => $value->languages_id,
                        'seometa_title' => $request->$seometa_title,
                        'seometa_desc' => $request->$seometa_desc,
                    ]);
                }
            }
        }

        if ($pages) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_PAGE_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_PAGE_ADD');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {

        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $response = WebPages::with('page_description', 'page_description.seo')->find($request->pages_id);
        } else {

            $response = LandingPages::with('page_description', 'page_description.seo')->find($request->pages_id);
        }
        $language = (new self)->language_list($api_token);

        $res = [
            'data_list' => $response,
            'language' => $language

        ];


        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        if ($userType == 'subscriber') {

            foreach (ApiHelper::allSupportLang() as $key => $value) {

                //validation check
                $validator = Validator::make(
                    $request->all(),
                    [
                        'pages_title_' . $value->languages_id => 'required',
                    ],
                    [

                        'pages_title_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'PAGE_TITLE_REQUIRED',
                    ]

                );
                if ($validator->fails()) {
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
                }
            }

            $pages_id = $request->pages_id;

            // store pages
            $saveData = $request->only(['sort_order', 'noindex']);
            $pages = WebPages::where('pages_id', $pages_id)->update($saveData);

            foreach (ApiHelper::allSupportLang() as $key => $value) {

                $pages_title = "pages_title_" . $value->languages_id;
                $pages_content = "pages_content_" . $value->languages_id;
                $seometa_title = "seometa_title_" . $value->languages_id;
                $seometa_desc = "seometa_desc_" . $value->languages_id;

                if ($value->languages_code == 'en') {
                    $page_data = WebPages::find($pages_id);

                    if (empty($request->pages_slug)) {
                        $page_data->pages_slug = Str::slug($request->$pages_title);
                    } else {

                        $page_data->pages_slug = $request->pages_slug;
                    }

                    $page_data->save();
                }

                $Pagedesc = WebPagesDescription::updateOrCreate([
                    'pages_id' => $pages_id,
                    'language_id' => $value->languages_id,
                ], [

                    'pages_title' => $request->$pages_title,
                    'pages_content' => $request->$pages_content,

                ]);

                if (!empty($request->$seometa_title) || !empty($request->$seometa_desc)) {
                    // create new
                    SeoMeta::updateOrCreate([
                        'page_type' => 3,
                        'reference_id' => $Pagedesc->page_description_id,
                        'language_id' => $value->languages_id,
                    ], [
                        'seometa_title' => $request->$seometa_title,
                        'seometa_desc' => $request->$seometa_desc,
                    ]);
                }
            }
        } else {

            foreach (ApiHelper::allSuperSupportLang() as $key => $value) {

                //validation check
                $validator = Validator::make(
                    $request->all(),
                    [
                        'pages_title_' . $value->languages_id => 'required',
                    ],
                    [

                        'pages_title_' . $value->languages_id . '.required' => $value->languages_name . '_' . 'PAGE_TITLE_REQUIRED',

                    ]

                );
                if ($validator->fails()) {
                    return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
                }
            }

            $pages_id = $request->pages_id;

            // store pages
            $saveData = $request->only(['sort_order', 'noindex']);
            $pages = LandingPages::where('pages_id', $pages_id)->update($saveData);

            foreach (ApiHelper::allSuperSupportLang() as $key => $value) {

                $pages_title = "pages_title_" . $value->languages_id;
                $pages_content = "pages_content_" . $value->languages_id;
                $seometa_title = "seometa_title_" . $value->languages_id;
                $seometa_desc = "seometa_desc_" . $value->languages_id;

                if ($value->languages_code == 'en') {
                    $page_data = LandingPages::find($pages_id);

                    if (empty($request->pages_slug)) {
                        $page_data->pages_slug = Str::slug($request->$pages_title);
                    } else {
                        $page_data->pages_slug = $request->pages_slug;
                    }

                    $page_data->save();
                }

                $Pagedesc = LandingPagesDescription::updateOrCreate([
                    'pages_id' => $pages_id,
                    'language_id' => $value->languages_id,
                ], [

                    'pages_title' => $request->$pages_title,
                    'pages_content' => $request->$pages_content,

                ]);

                if (!empty($request->$seometa_title) || !empty($request->$seometa_desc)) {
                    // create new
                    LandingSeoMeta::updateOrCreate([
                        'page_type' => 2,
                        'reference_id' => $Pagedesc->page_description_id,
                        'language_id' => $value->languages_id,
                    ], [
                        'seometa_title' => $request->$seometa_title, 'seometa_desc' => $request->$seometa_desc,
                    ]);
                }
            }
        }

        if ($pages) {
            return ApiHelper::JSON_RESPONSE(true, $saveData, 'SUCCESS_PAGES_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_PAGES_UPDATE');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->pages_id;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pagestatus)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $role_name = ApiHelper::get_role_from_token($api_token);

        $userType = ApiHelper::userType($api_token);


        if ($userType == 'subscriber') {
            $status = WebPages::destroy($id);
            $status2 = WebPagesDescription::destroy($id);
        } else {

            $status = LandingPages::destroy($id);
            $status2 = LandingPagesDescription::destroy($id);
        }

        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_PAGE_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_PAGE_DELETE');
        }
    }

    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;

        $userType = ApiHelper::userType($api_token);

        if ($userType == 'subscriber') {
            $infoData = WebPages::find($request->pages_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        } else {

            $infoData = LandingPages::find($request->pages_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        }

        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_STATUS_UPDATE');
    }

    public function view(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        if ($userType == 'subscriber') {

            $response = WebPages::with('page_description', 'page_description.seo')->find($request->pages_id);
        } else {

            $response = LandingPages::with('page_description', 'page_description.seo')->find($request->pages_id);
        }
        $language = (new self)->language_list($api_token);

        $res = [
            'data_list' => $response,
            'language' => $language

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function sortOrder(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $pages_id = $request->pages_id;
        $sort_order = $request->sort_order;
        if ($userType == 'subscriber') {

            $infoData =  WebPages::find($pages_id);
            if (empty($infoData)) {
                $infoData = new WebPages();
                $infoData->pages_id = $pages_id;
                $infoData->sort_order = $sort_order;


                $infoData->save();
            } else {
                $infoData->sort_order = $sort_order;
                $infoData->save();
            }
        } else {

            $infoData =  LandingPages::find($pages_id);
            if (empty($infoData)) {
                $infoData = new LandingPages();
                $infoData->pages_id = $pages_id;
                $infoData->sort_order = $sort_order;


                $infoData->save();
            } else {
                $infoData->sort_order = $sort_order;
                $infoData->save();
            }
        }




        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_SORT_ORDER_UPDATE');
    }
}
