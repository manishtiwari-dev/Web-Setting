<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Modules\WebsiteSetting\Models\PostCategory;
use Modules\WebsiteSetting\Models\PostToCategory;
use Modules\WebsiteSetting\Models\Form;
use Modules\WebsiteSetting\Models\Super\SuperPostCategory;


use Illuminate\Support\Str;

use ApiHelper;


class PostCategoryController extends Controller
{
    public $page = 'blog_setting';
    public $landingpage = 'super_blog_setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int) $request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        $language = $request->language;



        if ($userType == 'subscriber') {
            //  $data_query = PostCategory::query();

            $data_query = PostCategory::where('parent_id', 0);

            if (!empty($search)) {
                $data_query = $data_query->where("category_name", "LIKE", "%{$search}%");
            }

            // if (!empty($search))
            //     $data_query = $data_query->where("post_title","LIKE", "%{$search}%");

            /* order by sorting */
            if (!empty($sortBY) && !empty($ASCTYPE)) {
                $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
            } else {
                $data_query = $data_query->orderBy('sort_order', 'ASC');
            }

            $skip = ($current_page == 1) ? 0 : (int) ($current_page - 1) * $perPage;

            $user_count = $data_query->count();

            $data_list = $data_query->skip($skip)->take($perPage)->get();
            $data_list = $data_list->map(function ($data)  use ($language) {
                $data->image = ApiHelper::getFullImageUrl($data->image_id);

                // getting sub cate
                $sub_cat = PostCategory::where('parent_id', $data->category_id)->get();

                if (sizeof($sub_cat) > 0) {
                    $sub_cat = $sub_cat->map(function ($sub) {
                        $sub->image = ApiHelper::getFullImageUrl($sub->image_id);
                        return $sub;
                    });
                }

                $data->sub_cat = $sub_cat;
                return $data;
            });
        } else {

            //  $data_query = SuperPostCategory::query();
            $data_query = SuperPostCategory::where('parent_id', 0);

            if (!empty($search)) {
                $data_query = $data_query->where("category_name", "LIKE", "%{$search}%");
            }

            // if (!empty($search))
            //     $data_query = $data_query->where("post_title","LIKE", "%{$search}%");

            /* order by sorting */
            if (!empty($sortBY) && !empty($ASCTYPE)) {
                $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
            } else {
                $data_query = $data_query->orderBy('sort_order', 'ASC');
            }

            $skip = ($current_page == 1) ? 0 : (int) ($current_page - 1) * $perPage;

            $user_count = $data_query->count();

            $data_list = $data_query->skip($skip)->take($perPage)->get();
            $data_list = $data_list->map(function ($data)  use ($language) {
                $data->image = ApiHelper::getFullImageUrl($data->image_id);

                // getting sub cate
                $sub_cat = SuperPostCategory::where('parent_id', $data->category_id)->get();

                if (sizeof($sub_cat) > 0) {
                    $sub_cat = $sub_cat->map(function ($sub) {
                        $sub->image = ApiHelper::getFullImageUrl($sub->image_id);
                        return $sub;
                    });
                }
                $data->sub_cat = $sub_cat;
                return $data;
            });
        }




        // $data->feature_icon = ApiHelper::getFullImageUrl($data->feature_icon);

        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int) $user_count / (int) $perPage),
            'per_page' => $perPage,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function create(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        if ($userType == 'subscriber') {
            $parent_type = PostCategory::all();
        } else {
            $parent_type = SuperPostCategory::all();
        }
        $data = [

            'parent_type' => $parent_type,

        ];

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, '');
        else
            return ApiHelper::JSON_RESPONSE(false, [], '');
    }

    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        if ($userType == 'subscriber') {
            // store form 
            $saveData =  $request->only(['category_name', 'parent_id', 'image_id']);
            if ($saveData['image_id'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['image_id'], 1, 'postCategory', '', false);
            }

            $saveData['category_slug'] = Str::slug($request->category_name);
            $postCategory = PostCategory::create($saveData);
        } else {

            // store form 
            $saveData =  $request->only(['category_name', 'parent_id', 'image_id']);
            $saveData['category_slug'] = Str::slug($request->category_name);

            if ($saveData['image_id'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['image_id'], 1, 'postCategory', '', false);
            }


            $postCategory = SuperPostCategory::create($saveData);
        }





        return ApiHelper::JSON_RESPONSE(true, $postCategory, 'SUCCESS_POST_CATEGORY_ADD');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);



        if ($userType == 'subscriber') {
            $data_list = PostCategory::find($request->category_id);
            if (!empty($data_list))
                $data_list->banner_cat_image = ApiHelper::getFullImageUrl($data_list->image_id, 'index-list');
            $parent_type = PostCategory::all();
        } else {

            $data_list = SuperPostCategory::find($request->category_id);
            if (!empty($data_list))
                $data_list->banner_cat_image = ApiHelper::getFullImageUrl($data_list->image_id, 'index-list');
            $parent_type = SuperPostCategory::all();
        }



        $data = [
            'data_list' => $data_list,
            'parent_type' => $parent_type,

        ];


        return ApiHelper::JSON_RESPONSE(true, $data, '');
    }

    //This Function is used to update the particular plan data
    public function update(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $category_id = $request->category_id;


        if ($userType == 'subscriber') {
            $saveData =  $request->only(['category_name', 'parent_id', 'image_id', 'status']);
            $saveData['category_slug'] = Str::slug($request->category_name);

            if ($saveData['image_id'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['image_id'], 1, 'postCategory', '', false);
            }

            PostCategory::where('category_id', $category_id)->update($saveData);
        } else {

            $saveData =  $request->only(['category_name', 'parent_id', 'image_id', 'status']);
            $saveData['category_slug'] = Str::slug($request->category_name);

            if ($saveData['image_id'] != '') {
                ApiHelper::image_upload_with_crop($api_token, $saveData['image_id'], 1, 'postCategory', '', false);
            }


            SuperPostCategory::where('category_id', $category_id)->update($saveData);
        }



        return ApiHelper::JSON_RESPONSE(true, $saveData, 'SUCCESS_POST_CATEGORY_UPDATE');
    }



    //This Function is used to get the change the form status
    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $infoData = PostCategory::find($request->category_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        } else {

            $infoData = SuperPostCategory::find($request->category_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        }


        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_STATUS_UPDATE');
    }

    public function sortOrder(Request $request)
    {
        $api_token = $request->api_token;
        $category_id = $request->category_id;
        $sort_order = $request->sort_order;


        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $infoData =  PostCategory::find($category_id);
            if (empty($infoData)) {
                $infoData = new PostCategory();
                $infoData->category_id = $category_id;
                $infoData->sort_order = $sort_order;


                $infoData->save();
            } else {
                $infoData->sort_order = $sort_order;
                $infoData->save();
            }
        } else {
            $infoData =  SuperPostCategory::find($category_id);
            if (empty($infoData)) {
                $infoData = new SuperPostCategory();
                $infoData->category_id = $category_id;
                $infoData->sort_order = $sort_order;


                $infoData->save();
            } else {
                $infoData->sort_order = $sort_order;
                $infoData->save();
            }
        }




        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_SORT_ORDER_UPDATE');
    }
}
