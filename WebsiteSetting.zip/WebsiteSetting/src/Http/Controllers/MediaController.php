<?php

namespace Modules\WebsiteSetting\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Modules\WebsiteSetting\Models\Images;
use App\Models\Language;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\TempImages;
use ApiHelper;
use File;
use Modules\WebsiteSetting\Models\Super\LandingImages;



class MediaController extends Controller
{


    public $page = 'web_media';
    public $landingpage = 'web_media';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        if ($userType == 'subscriber') {
            $data_query = Images::query();
            if (!empty($search))
                $data_query = $data_query->where("images_ori_name", "LIKE", "%{$search}%");

            $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;

            $user_count = $data_query->count();

            $data_list = $data_query->orderBy('images_id', 'desc')->skip($skip)->take($perPage)->get();
            //$data_list = $data_query->orderBy('images_id', 'desc')->paginate($perPage);

            $data_list = $data_list->map(function ($data) {
                $data->media_image = ApiHelper::getFullImageUrl($data->images_id);
                return $data;
            });
        } else {
            $data_query = LandingImages::query();
            if (!empty($search))
                $data_query = $data_query->where("images_ori_name", "LIKE", "%{$search}%");

            $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;

            $user_count = $data_query->count();

            $data_list = $data_query->orderBy('images_id', 'desc')->skip($skip)->take($perPage)->get();
            //$data_list = $data_query->orderBy('images_id', 'desc')->paginate($perPage);

            $data_list = $data_list->map(function ($data) {
                $data->media_image = ApiHelper::getLandingImageUrl($data->images_id);
                return $data;
            });
        }


        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage,
            // 'page_position' => ((22-1) * 24), //page position
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }



    public function show(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        if ($userType == 'subscriber') {
            $data_query = Images::where('images_id', $request->images_id);
            if (!empty($search))
                $data_query = $data_query->where("images_ori_name", "LIKE", "%{$search}%");

            $data_list = $data_query->get();

            $data_list = $data_list->map(function ($data) {

                $data->media_image = ApiHelper::getFullImageUrl($data->images_id);

                return $data;
            });
        } else {
            $data_query = LandingImages::where('images_id', $request->images_id);
            if (!empty($search))
                $data_query = $data_query->where("images_ori_name", "LIKE", "%{$search}%");

            $data_list = $data_query->get();

            $data_list = $data_list->map(function ($data) {

                $data->media_image = ApiHelper::getLandingImageUrl($data->images_id);

                return $data;
            });
        }






        $res = [
            'media_list' => $data_list,

        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }



    public function store(Request $request)
    {

        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');



        if ($userType == 'subscriber') {

            $image = $insData = array();
            $image_name = '';
            $ext = '';
            $image = $request->file('file');

            if (!empty($image)) {
                $times = time();
                $extension = $image->getClientOriginalExtension();
                $images_ori_name  = $image->getClientOriginalName();

                $dir = "temp/" . $times;

                $path = $image->storeAs($dir, $times . '.' . $extension);

                $tmpimage = TempImages::create([
                    'images_name' => $times,
                    'images_ext' => $extension,
                    'images_directory' => $dir,
                    'images_size' => '',
                    'images_ori_name' => $images_ori_name
                ]);
                $insertedId = $tmpimage->images_id;
                ApiHelper::image_upload_with_crop($api_token, $insertedId, 1, $insertedId, 'gallery', true);

                $insData = [
                    'images_id' => $insertedId,
                    'images_url' => ApiHelper::getFullImageUrl($insertedId),
                ];
            }
        } else {


            $image = $insData = array();
            $image_name = '';
            $ext = '';
            $image = $request->file('file');

            if (!empty($image)) {
                $times = time();
                $extension = $image->getClientOriginalExtension();
                $images_ori_name  = $image->getClientOriginalName();

                $dir = "temp/" . $times;

                $path = $image->storeAs($dir, $times . '.' . $extension);

                $tmpimage = LandingImages::create([
                    'images_name' => $times,
                    'images_ext' => $extension,
                    'images_directory' => $dir,
                    'images_size' => '',
                    'images_ori_name' => $images_ori_name
                ]);
                $insertedId = $tmpimage->images_id;
                ApiHelper::landing_image_upload_with_crop($api_token, $insertedId, 1, $insertedId, 'gallery', true);

                $insData = [
                    'images_id' => $insertedId,
                    'images_url' => ApiHelper::getFullImageUrl($insertedId),
                ];
            }
        }




        if ($insData)
            return ApiHelper::JSON_RESPONSE(true, $insData, 'SUCCESS_MEDIA_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_MEDIA_ADD');
    }

    public function destroy(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access = ($userType == 'subscriber' ? $this->page : $this->landingpage);
        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $id = $request->images_id;

        if ($userType == 'subscriber') {
            $status = Images::destroy($id);
        } else {
            $status = LandingImages::destroy($id);
        }


        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_MEDIA_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_MEDIA_DELETE');
        }
    }
}
