<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\Super\LandingMenuGroup;

class LandingMenu extends Model
{
    use HasFactory;

    protected $primaryKey = "menu_id";

    protected $guarded = [

        'menu_id',
    ];


    public function getTable()
    {
        return config('dbtable.landing_web_menu');
    }

    public function bannerGroup()
    {
        return $this->belongsTo(LandingMenuGroup::class, 'group_id', 'group_id');
    }

    public function menuDetails()
    {
        return $this->hasMany(LandingMenuDetails::class, 'menu_id', 'menu_id');
    }
}
