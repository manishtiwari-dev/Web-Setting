<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\PostDescriptions;


class SuperPostCategory extends Model
{
    use HasFactory;

    protected $primaryKey = "category_id";

    public $timestamps = false;

    protected $guarded = [

        'category_id',
    ];


    public function getTable()
    {
        return config('dbtable.super_web_post_category');
    }
}
