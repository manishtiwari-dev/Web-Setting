<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\Super\LandingSeoMeta;


class LandingPostDescription extends Model
{
    use HasFactory;

    protected $primaryKey = "post_description";

    public $timestamps = false;

    protected $guarded=[
     
     'post_description',


    ];
     
    
    public function getTable()
    {
        return config('dbtable.landing_web_post_descriptions');

    }

    public function seo(){
        return $this->hasOne(LandingSeoMeta::class, 'reference_id','post_description');
    }
    

}