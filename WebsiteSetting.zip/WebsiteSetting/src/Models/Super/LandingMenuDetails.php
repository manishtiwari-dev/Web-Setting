<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LandingMenuDetails extends Model
{
    use HasFactory;



    protected $fillable = [
        'menu_id',
        'languages_id',
        'menu_name',
        'created_at',
        'updated_at',
        'menu_label'
    ];


    public function getTable()
    {
        return config('dbtable.landing_web_menu_details');
    }
}
