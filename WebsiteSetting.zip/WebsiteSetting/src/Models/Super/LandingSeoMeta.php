<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class LandingSeoMeta extends Model
{
    use HasFactory;

    protected $primaryKey = "seometa_id";

    public $timestamps = false;

    protected $guarded=[
     
     'seometa_id',
    ];
     

    
    public function getTable()
    {
        return config('dbtable.landing_web_seometa');
    }

   
}
