<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LandingFormField extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $primaryKey = 'fields_id';
    protected $guarded = ['fields_id'];

    public function getTable()
    {
        return config('dbtable.landing_crm_form_fields');
    }
}
