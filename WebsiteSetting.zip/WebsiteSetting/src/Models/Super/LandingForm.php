<?php

namespace Modules\WebsiteSetting\Models\Super;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\Super\LandingFormField;
use Modules\WebsiteSetting\Models\Super\LandingFormData;


class LandingForm extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $primaryKey = 'form_id';
    protected $guarded = ['form_id'];

    public function getTable()
    {
        return config('dbtable.landing_crm_form');
    }

    public function form_field()
    {
        return $this->hasMany(LandingFormField::class, 'form_id', 'form_id');
    }

    public function form_data()
    {
        return $this->hasMany(LandingFormData::class, 'form_id', 'form_id');
    }
}
