<?php

namespace Modules\WebsiteSetting\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LandingFormData extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $primaryKey = 'form_data_id';
    protected $guarded = ['form_data_id'];

    public function getTable()
    {
        return config('dbtable.landing_crm_form_data');
    }
}
