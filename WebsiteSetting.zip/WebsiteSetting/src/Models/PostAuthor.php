<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\PostDescriptions;


class PostAuthor extends Model
{
    use HasFactory;

    protected $primaryKey = "author_id";

    public $timestamps = false;

    protected $guarded = [

        'author_id',
    ];


    public function getTable()
    {
        return config('dbtable.web_post_author');
    }
}
