<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Ecommerce\Models\SeoMeta;


class PostDescriptions extends Model
{
    use HasFactory;

    protected $primaryKey = "post_description";

    public $timestamps = false;

    protected $guarded=[
     
     'post_description',


    ];
     
    
    public function getTable()
    {
        return config('dbtable.web_post_descriptions');

    }

    
    public function seo(){
        return $this->hasOne(SeoMeta::class, 'reference_id','post_description')->where('page_type', 4);
    }


}