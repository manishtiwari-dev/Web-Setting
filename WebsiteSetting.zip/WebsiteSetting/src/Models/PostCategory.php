<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\WebsiteSetting\Models\PostDescriptions;


class PostCategory extends Model
{
    use HasFactory;

    protected $primaryKey = "category_id";

    public $timestamps = false;

    protected $guarded = [

        'category_id',
    ];


    public function getTable()
    {
        return config('dbtable.web_post_category');
    }
}
