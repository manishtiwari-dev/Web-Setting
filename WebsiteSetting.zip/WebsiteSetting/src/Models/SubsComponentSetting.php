<?php

namespace Modules\WebsiteSetting\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;



class SubsComponentSetting extends Model
{
    use HasFactory;

    protected $primaryKey='setting_id';
    
    public $timestamps = false;
    protected $fillable = ['setting_id', 'sort_order', 'status'];
     
        
    public function getTable()
    {
        return config('dbtable.subscriber_web_template_component_setting');
    }


    
}
