<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use Modules\WebsiteSetting\Http\Controllers\FormController;
use Modules\WebsiteSetting\Http\Controllers\WebsiteSettingController;
use Modules\WebsiteSetting\Http\Controllers\WebTemplateController;
use Modules\WebsiteSetting\Http\Controllers\WebFunctionController;
use Modules\WebsiteSetting\Http\Controllers\SliderImagesController;
use Modules\WebsiteSetting\Http\Controllers\SliderController;
use Modules\WebsiteSetting\Http\Controllers\BannerController;
use Modules\WebsiteSetting\Http\Controllers\BannerGroupController;
use Modules\WebsiteSetting\Http\Controllers\MenuController;
use Modules\WebsiteSetting\Http\Controllers\MenuGroupController;
use Modules\WebsiteSetting\Http\Controllers\MediaController;
use Modules\WebsiteSetting\Http\Controllers\PagesController;
use Modules\WebsiteSetting\Http\Controllers\EmailGroupController;
use Modules\WebsiteSetting\Http\Controllers\EmailTemplateController;
use Modules\WebsiteSetting\Http\Controllers\PostController;
use Modules\WebsiteSetting\Http\Controllers\PostCategoryController;
use Modules\WebsiteSetting\Http\Controllers\PostTagController;
use Modules\WebsiteSetting\Http\Controllers\PostAuthorController;
use Modules\WebsiteSetting\Http\Controllers\WebTestimonialController;
use Modules\WebsiteSetting\Http\Controllers\WebfaqController;
use Modules\WebsiteSetting\Http\Controllers\OrderStatusController;
use Modules\WebsiteSetting\Http\Controllers\WebLinkController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['middleware' => ['ApiTokenCheck'], 'prefix' => "api/"], function () {


    //custom form
    Route::group(['prefix' => 'form'], function () {
        Route::post('/', [FormController::class, 'index']);
        Route::post('/store', [FormController::class, 'store']);
        Route::post('/edit', [FormController::class, 'edit']);
        Route::post('/update', [FormController::class, 'update']);
        Route::post('/delete', [FormController::class, 'destroy']);
        Route::post('/form_type', [FormController::class, 'form_type']);
        Route::post('/changeStatus', [FormController::class, 'changeStatus']);
    });




    // Website Settings Methods prefix
    Route::group(['prefix' => 'websettings'], function () {
        Route::post('/', [WebsiteSettingController::class, 'index']);
        Route::post('/update', [WebsiteSettingController::class, 'update']);
    });



    // Web Templates prefix
    Route::group(['prefix' => 'template'], function () {
        Route::post('/', [WebTemplateController::class, 'index_all']);
        Route::post('/list', [WebTemplateController::class, 'create']);
        Route::post('/detail', [WebTemplateController::class, 'template_detail']);
        Route::post('/store', [WebTemplateController::class, 'template_store']);
        Route::post('/template_store', [WebTemplateController::class, 'template_setting_store']);
        Route::post('/edit', [WebTemplateController::class, 'template_edit']);
        Route::post('/update', [WebTemplateController::class, 'template_update']);
        Route::post('/componentlist', [WebTemplateController::class, 'component_setting_list']);
        Route::post('/componentsetting/store', [WebTemplateController::class, 'component_setting_store']);
        Route::post('/componentsetting/delete', [WebTemplateController::class, 'destroy']);

        Route::post('/sectionlist', [WebTemplateController::class, 'section_list']);
        Route::post('/sectionStore', [WebTemplateController::class, 'template_section_store']);
        Route::post('/sectionEdit', [WebTemplateController::class, 'section_edit']);
        Route::post('/sectionUpdate', [WebTemplateController::class, 'template_section_update']);
        Route::post('/sectionGroupStore', [WebTemplateController::class, 'template_section_group_store']);
        Route::post('/sectionGroupedit', [WebTemplateController::class, 'section_group_edit']);
        Route::post('/sectionGroupUpdate', [WebTemplateController::class, 'template_section_group_update']);
        Route::post('/changeStatus', [WebTemplateController::class, 'changeStatus']);

        Route::post('/template_html', [WebTemplateController::class, 'template_html']);
        Route::post('/template_html_update', [WebTemplateController::class, 'template_html_update']);
        Route::post('/template_setting_html_update', [WebTemplateController::class, 'template_setting_html_update']);
    });
    // end Web Templates prefix

    //Web function Prefix
    Route::group(['prefix' => 'webfunction'], function () {
        Route::post('/', [WebFunctionController::class, 'index']);
        Route::post('/changeStatus', [WebFunctionController::class, 'changeStatus']);
    });

    //end prefix

    //Order status Setting Prefix
    Route::group(['prefix' => 'orderStatus'], function () {
        Route::post('/', [OrderStatusController::class, 'index']);
        Route::post('/changeStatus', [OrderStatusController::class, 'changeStatus']);
        Route::post('/sort_order', [OrderStatusController::class, 'sort_order']);
        Route::post('/shipment_status', [OrderStatusController::class, 'shipment_status']);
        Route::post('/order_template_update', [OrderStatusController::class, 'order_template_update']);
    });

    //end prefix


    //Slider

    Route::group(['prefix' => 'slider'], function () {
        Route::post('/', [SliderController::class, 'index']);
        Route::post('/store', [SliderController::class, 'store']);
        Route::post('/edit', [SliderController::class, 'edit']);
        Route::post('/update', [SliderController::class, 'update']);
        Route::post('/changeStatus', [SliderController::class, 'changeStatus']);
    });

    // slider

    // slider images Methods prefix
    Route::group(['prefix' => 'sliderImages'], function () {
        Route::post('/', [SliderImagesController::class, 'index']);

        Route::post('/list', [SliderImagesController::class, 'list']);
        Route::post('/store', [SliderImagesController::class, 'store']);
        Route::post('/edit', [SliderImagesController::class, 'edit']);
        Route::post('/update', [SliderImagesController::class, 'update']);
        Route::post('/destroy', [SliderImagesController::class, 'destroy']);
        Route::post('/changeStatus', [SliderImagesController::class, 'changeStatus']);
        Route::post('/sortOrder', [SliderImagesController::class, 'sortOrder']);
    });




    // Website Banner Methods prefix
    Route::group(['prefix' => 'banner'], function () {
        Route::post('/list', [BannerController::class, 'list']);
        Route::post('/store', [BannerController::class, 'store']);
        Route::post('/edit', [BannerController::class, 'edit']);
        Route::post('/update', [BannerController::class, 'update']);
        Route::post('/destroy', [BannerController::class, 'destroy']);
        Route::post('/changeStatus', [BannerController::class, 'changeStatus']);
        Route::post('/sortOrder', [BannerController::class, 'sortOrder']);
    });

    //Web Banner Group prefix
    Route::group(['prefix' => 'bannerGroup'], function () {
        Route::post('/', [BannerController::class, 'index']);
        Route::post('/store', [BannerGroupController::class, 'store']);
        Route::post('/edit', [BannerGroupController::class, 'edit']);
        Route::post('/update', [BannerGroupController::class, 'update']);
        Route::post('/changeStatus', [BannerGroupController::class, 'changeStatus']);
    });

    //end Web Banner Group prefix

    //Web Menu prefix
    Route::group(['prefix' => 'menu'], function () {
        Route::post('/', [MenuController::class, 'list']);
        Route::post('/store', [MenuController::class, 'store']);
        Route::post('/edit', [MenuController::class, 'edit']);
        Route::post('/update', [MenuController::class, 'update']);
        Route::post('/destroy', [MenuController::class, 'destroy']);
        Route::post('/create', [MenuController::class, 'create']);
        Route::post('/changeStatus', [MenuController::class, 'changeStatus']);
        Route::post('/sortOrder', [MenuController::class, 'sortOrder']);
    });
    //end Web Menu prefix

    //Web Menu Group prefix
    Route::group(['prefix' => 'menugroup'], function () {
        Route::post('/', [MenuGroupController::class, 'index']);
        Route::post('/store', [MenuGroupController::class, 'store']);
        Route::post('/edit', [MenuGroupController::class, 'edit']);
        Route::post('/update', [MenuGroupController::class, 'update']);
        Route::post('/destroy', [MenuGroupController::class, 'destroy']);
        Route::post('/changeStatus', [MenuGroupController::class, 'changeStatus']);
    });
    //end Web Menu Group prefix



    //Media API
    Route::group(['prefix' => 'media'], function () {
        Route::post('/', [MediaController::class, 'index']);
        Route::post('/store', [MediaController::class, 'store']);
        Route::post('/destroy', [MediaController::class, 'destroy']);
        Route::post('/view', [MediaController::class, 'show']);
    });

    //starting of webpages
    Route::group(['prefix' => 'pages'], function () {
        Route::post('/', [PagesController::class, 'index']);
        Route::post('/store', [PagesController::class, 'store']);
        Route::post('/edit', [PagesController::class, 'edit']);
        Route::post('/create', [PagesController::class, 'create']);
        Route::post('/update', [PagesController::class, 'update']);
        Route::post('/destroy', [PagesController::class, 'destroy']);
        Route::post('/changeStatus', [PagesController::class, 'changeStatus']);
        Route::post('/view', [PagesController::class, 'view']);
        Route::post('/sortOrder', [PagesController::class, 'sortOrder']);
    });
    //ending of webpages


    //Web emailTemplate prefix
    Route::group(['prefix' => 'emailTemplate'], function () {
        Route::post('/', [EmailTemplateController::class, 'list']);
        Route::post('/store', [EmailTemplateController::class, 'store']);
        Route::post('/edit', [EmailTemplateController::class, 'edit']);
        Route::post('/update', [EmailTemplateController::class, 'update']);
        Route::post('/destroy', [EmailTemplateController::class, 'destroy']);
        Route::post('/create', [EmailTemplateController::class, 'create']);
        Route::post('/changeStatus', [EmailTemplateController::class, 'changeStatus']);
        Route::post('/view', [EmailTemplateController::class, 'view']);
    });

    //end Web emailTemplate prefix

    //Web emailGroup prefix
    Route::group(['prefix' => 'emailGroup'], function () {
        Route::post('/', [EmailGroupController::class, 'index']);
        Route::post('/store', [EmailGroupController::class, 'store']);
        Route::post('/create', [EmailGroupController::class, 'create']);
        Route::post('/edit', [EmailGroupController::class, 'edit']);
        Route::post('/update', [EmailGroupController::class, 'update']);
        Route::post('/destroy', [EmailGroupController::class, 'destroy']);
        Route::post('/changeStatus', [EmailGroupController::class, 'changeStatus']);
        Route::post('/sortOrder', [EmailGroupController::class, 'sortOrder']);
    });
    //ende mailGroup prefix



    //Web POST Prefix

    Route::group(['prefix' => 'post'], function () {
        Route::post('/', [PostController::class, 'index']);
        Route::post('/store', [PostController::class, 'store']);
        Route::post('/create', [PostController::class, 'create']);
        Route::post('/is_featured', [PostController::class, 'is_featured']);
        Route::post('/edit', [PostController::class, 'edit']);
        Route::post('/update', [PostController::class, 'update']);
        Route::post('/destroy', [PostController::class, 'destroy']);
        Route::post('/changeStatus', [PostController::class, 'changeStatus']);
        Route::post('/view', [PostController::class, 'view']);
    });



    Route::group(['prefix' => 'postCategory'], function () {
        Route::post('/', [PostCategoryController::class, 'index']);
        Route::post('/store', [PostCategoryController::class, 'store']);
        Route::post('/create', [PostCategoryController::class, 'create']);

        Route::post('/sortOrder', [PostCategoryController::class, 'sortOrder']);
        Route::post('/edit', [PostCategoryController::class, 'edit']);
        Route::post('/update', [PostCategoryController::class, 'update']);
        Route::post('/changeStatus', [PostCategoryController::class, 'changeStatus']);
    });



    Route::group(['prefix' => 'postTag'], function () {
        Route::post('/', [PostTagController::class, 'index']);
        Route::post('/store', [PostTagController::class, 'store']);
        Route::post('/edit', [PostTagController::class, 'edit']);
        Route::post('/update', [PostTagController::class, 'update']);
        Route::post('/changeStatus', [PostTagController::class, 'changeStatus']);
    });


    Route::group(['prefix' => 'postAuthor'], function () {
        Route::post('/', [PostAuthorController::class, 'index']);
        Route::post('/store', [PostAuthorController::class, 'store']);
        Route::post('/edit', [PostAuthorController::class, 'edit']);
        Route::post('/update', [PostAuthorController::class, 'update']);
        Route::post('/changeStatus', [PostAuthorController::class, 'changeStatus']);
    });




    //Web testimonial Prefix
    Route::group(['prefix' => 'testimonial'], function () {
        Route::post('/', [WebTestimonialController::class, 'index']);
        Route::post('/changeStatus', [WebTestimonialController::class, 'changeStatus']);
        Route::post('/store', [WebTestimonialController::class, 'store']);
        Route::post('/edit', [WebTestimonialController::class, 'edit']);
        Route::post('/update', [WebTestimonialController::class, 'update']);
        Route::post('/delete', [WebTestimonialController::class, 'destroy']);
    });

    //end prefix

    //Web Link API Urls
    Route::group(['prefix' => 'web-link'], function () {
        Route::post('/', [WebLinkController::class, 'index']);
        Route::post('/store', [WebLinkController::class, 'store']);
        Route::post('/edit', [WebLinkController::class, 'edit']);
        Route::post('/update', [WebLinkController::class, 'update']);
        Route::post('/delete', [WebLinkController::class, 'destroy']);
        Route::post('/changeStatus', [WebLinkController::class, 'changeStatus']);
    });


    //Faq API
    Route::group(['prefix' => 'faq'], function () {

        Route::post('/', [WebfaqController::class, 'list']);
        Route::post('/store', [WebfaqController::class, 'store']);
        Route::post('/edit', [WebfaqController::class, 'edit']);
        Route::post('/update', [WebfaqController::class, 'update']);
        Route::post('/groupAdd', [WebfaqController::class, 'group_store']);
        Route::post('/groupEdit', [WebfaqController::class, 'group_edit']);
        Route::post('/groupUpdate', [WebfaqController::class, 'group_update']);
        Route::post('/changeStatus', [WebfaqController::class, 'changeStatus']);
        Route::post('/sortOrder', [WebfaqController::class, 'sortOrder']);
        Route::post('/create', [WebfaqController::class, 'create']);
    });
});
